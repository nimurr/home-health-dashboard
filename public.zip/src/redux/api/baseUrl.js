
// const url = "http://192.168.10.168:5055"
// const url = "http://192.168.10.168:5050"
const url = "https://api.guidegadget.com"
export default url