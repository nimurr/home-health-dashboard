import React from 'react';
import Login from './Login';

const Home = () => {
    return (
        <div>
            <Login></Login>
            
        </div>
    );
};

export default Home;